<?php
 $db = mysqli_connect('localhost', 'root', '','arun') or
        die ('Unable to connect. Check your connection parameters.');
        mysqli_select_db($db, 'arun' ) or die(mysqli_error($db));
?>